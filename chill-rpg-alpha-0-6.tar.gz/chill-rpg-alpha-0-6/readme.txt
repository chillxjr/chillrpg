
   ***********************************************************
   *                                                         *
   *                                                         *
   *                  Chill's RPG Engine                     *
   *                                                         *
   *                                                         * 
   *                  Version alpha 0.6                      *
   *                                                         *
   *                                                         *
   *                                                         *
   *                                                         *
   *                                                         *
   ***********************************************************
    
    
    *** AS OF VERSION 0.6 CLINT IS REQUIRED ***
        
        I recommend pip to install it // FROM TERMINAL: pip3 install clint
        I also include a copy in the tarball in case pip doesn't work for you.

    To run it:
        cd /home/YOURUSERNAME/Downloads/chill-rpg-alpha-0-6
        python3 start.py
        
